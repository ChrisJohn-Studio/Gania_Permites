// Get query parameters from URL
const urlParams = new URLSearchParams(window.location.search);
        
// Retrieve form data
const name = urlParams.get('name');
const carModel = urlParams.get('carModel');
const rentalDays = parseInt(urlParams.get('rentalDays'), 10);
const pricePerDay = parseFloat(urlParams.get('pricePerDay'));

// Generate a random Rental ID (could also be tied to a database in a real system)
const rentalId = Math.floor(Math.random() * 1000000);

// Calculate total price
const totalPrice = rentalDays * pricePerDay;

// Get the current date and time
const currentDateTime = new Date();
const dateTimeString = currentDateTime.toLocaleString();

// Display the data
document.getElementById('rentalId').textContent = rentalId;
document.getElementById('name').textContent = name;
document.getElementById('carModel').textContent = carModel;
document.getElementById('rentalDays').textContent = rentalDays;
document.getElementById('pricePerDay').textContent = pricePerDay.toFixed(2);
document.getElementById('totalPrice').textContent = totalPrice.toFixed(2);
document.getElementById('dateTime').textContent = dateTimeString;
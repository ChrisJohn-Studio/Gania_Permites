<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_rental";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Delete Request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM rentals WHERE id = $delete_id";
    $conn->query($deleteQuery);
    header('Location: view_rentals.php'); // Redirect to refresh the page
}

// Handle Update Request
if (isset($_POST['update_id'])) {
    $update_id = $_POST['update_id'];
    $newCarModel = $_POST['carModel'];
    $newRentalDays = $_POST['rentalDays'];
    
    $updateQuery = "UPDATE rentals SET car_model = '$newCarModel', rental_days = $newRentalDays WHERE id = $update_id";
    $conn->query($updateQuery);
    header('Location: view_rentals.php'); // Redirect to refresh the page
}

// Fetch Rentals
$sql = "SELECT * FROM rentals";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Rentals</title>
    <style>
        /* General body styles */
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('showcase.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        /* Heading styles */
        h1 {
            color: #fff;
            margin-bottom: 20px;
            text-align: center;
            font-size: 2.5em;
        }

        /* Container for the rental records */
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Table styles */
        table.rental-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table.rental-table th, table.rental-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table.rental-table th {
            background-color: #007BFF;
            color: #fff;
        }

        table.rental-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table.rental-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Links (Delete/Edit) */
        a {
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Button style */
        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: white;
            padding: 12px 25px;
            margin-top: 20px;
            text-decoration: none;
            border-radius: 6px;
            text-align: center;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                width: 90%;
            }

            table.rental-table th, table.rental-table td {
                padding: 10px;
            }

            h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Rental Records</h1>
        
        <table class="rental-table">
            <thead>
                <tr>
                    <th>Rental ID</th>
                    <th>Customer Name</th>
                    <th>Car Model</th>
                    <th>Rental Days</th>
                    <th>Price per Day</th>
                    <th>Total Cost</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['car_model'] . "</td>";
                        echo "<td>" . $row['rental_days'] . "</td>";
                        echo "<td>" . $row['price_per_day'] . "</td>";
                        echo "<td>" . $row['total_cost'] . "</td>";
                        echo "<td>
                            <a href='view_rentals.php?delete_id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this rental?\")'>Delete</a> |
                            <a href='edit_rental.php?edit_id=" . $row['id'] . "'>Edit</a>
                        </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' style='text-align:center;'>No rentals found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        
        <a href="car_rental_form.html" class="btn">Rent More Cars</a>
    </div>

</body>
</html>

<?php
// Close connection
$conn->close();
?>

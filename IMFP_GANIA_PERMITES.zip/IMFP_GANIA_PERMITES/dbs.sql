CREATE DATABASE car_rental;

USE car_rental;

CREATE TABLE rentals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    car_model VARCHAR(255),
    rental_days INT,
    price_per_day DECIMAL(10, 2),
    total_cost DECIMAL(10, 2)
    
);
CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_model VARCHAR(100),
    price_per_day DECIMAL(10, 2)
);
INSERT INTO cars (car_model, price_per_day) VALUES
('Toyota Camry', 50),
('Honda Civic', 40),
('BMW 3 Series', 80),
('Audi A4', 75),
('Ford Mustang', 90);

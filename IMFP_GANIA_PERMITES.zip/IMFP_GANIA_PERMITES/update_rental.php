<?php
// Assuming database connection is established before this
// Fetch the rental details from the database
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM rentals WHERE id = $id");
    $rental = $result->fetch_assoc();
} else {
    die("Rental not found.");
}
?>

<form action="update_rental_process.php" method="POST">
    <!-- Hidden field to store the rental ID -->
    <input type="hidden" name="id" value="<?php echo $rental['id']; ?>">

    <div class="form-group">
        <label for="carModel">Car Model:</label>
        <select name="carModel" id="carModel" onchange="updatePrice()" required>
            <option value="Toyota Camry" <?php echo ($rental['car_model'] == 'Toyota Camry') ? 'selected' : ''; ?>>Toyota Camry</option>
            <option value="Honda Civic" <?php echo ($rental['car_model'] == 'Honda Civic') ? 'selected' : ''; ?>>Honda Civic</option>
            <option value="BMW 3 Series" <?php echo ($rental['car_model'] == 'BMW 3 Series') ? 'selected' : ''; ?>>BMW 3 Series</option>
            <option value="Audi A4" <?php echo ($rental['car_model'] == 'Audi A4') ? 'selected' : ''; ?>>Audi A4</option>
            <option value="Ford Mustang" <?php echo ($rental['car_model'] == 'Ford Mustang') ? 'selected' : ''; ?>>Ford Mustang</option>
        </select>
    </div>

    <div class="form-group">
        <label for="rentalDays">Number of Rental Days:</label>
        <input type="number" id="rentalDays" name="rentalDays" value="<?php echo $rental['rental_days']; ?>" oninput="updateTotalCost()" required>
    </div>

    <div class="form-group">
        <label for="pricePerDay">Price per Day:</label>
        <input type="number" name="pricePerDay" id="pricePerDay" value="<?php echo $rental['price_per_day']; ?>" readonly required>
    </div>

    <div class="form-group">
        <label for="totalCost">Total Cost:</label>
        <input type="text" name="totalCost" id="totalCost" value="<?php echo $rental['total_cost']; ?>" readonly required>
    </div>

    <input type="submit" value="Update Rental">
</form>

<script>
// Car prices
const carPrices = {
    "Toyota Camry": 50,
    "Honda Civic": 40,
    "BMW 3 Series": 80,
    "Audi A4": 75,
    "Ford Mustang": 90
};

function updatePrice() {
    const carModel = document.getElementById('carModel').value;
    const pricePerDayField = document.getElementById('pricePerDay');

    if (carPrices[carModel]) {
        pricePerDayField.value = carPrices[carModel];
        updateTotalCost();
    }
}

function updateTotalCost() {
    const rentalDays = parseInt(document.getElementById('rentalDays').value);
    const pricePerDay = parseFloat(document.getElementById('pricePerDay').value);

    if (!isNaN(rentalDays) && rentalDays > 0 && !isNaN(pricePerDay) && pricePerDay > 0) {
        const totalCost = rentalDays * pricePerDay;
        document.getElementById('totalCost').value = totalCost.toFixed(2);
    }
}

// Initialize the price based on the selected car model on page load
window.onload = function() {
    updatePrice();
};
</script>

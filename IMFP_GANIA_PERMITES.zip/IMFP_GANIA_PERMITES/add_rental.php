<?php
// Database connection
$servername = "localhost";  // Database server (usually localhost)
$username = "root";         // Database username (change to your username)
$password = "";             // Database password (change to your password)
$dbname = "car_rental";     // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all car models from the database or use a hardcoded list
$carModels = [
    "Toyota Camry", "Honda Civic", "BMW 3 Series", "Audi A4", "Ford Mustang"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Rental</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="form-container">
        <h2>Add New Rental</h2>
        <form action="submit_rental.php" method="POST" onsubmit="return calculateTotalCost()">
            <div class="form-group">
                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="carModel">Car Model:</label>
                <select id="carModel" name="carModel" required onchange="updateCarImage()">
                    <option value="">Select a Car Model</option>
                    <?php foreach ($carModels as $carModel) { ?>
                        <option value="<?php echo $carModel; ?>"><?php echo $carModel; ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rentalDays">Number of Rental Days:</label>
                <input type="number" id="rentalDays" name="rentalDays" required>
            </div>

            <div class="form-group">
                <label for="pricePerDay">Price per Day ($):</label>
                <input type="number" id="pricePerDay" name="pricePerDay" required readonly>
            </div>

            <div class="form-group">
                <label for="totalCost">Total Cost ($):</label>
                <input type="text" id="totalCost" name="totalCost" readonly>
            </div>

            <input type="submit" value="Add Rental">
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>

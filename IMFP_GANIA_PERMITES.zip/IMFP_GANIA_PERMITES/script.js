const carPrices = {
    "Toyota Camry": 50,
    "Honda Civic": 40,
    "BMW 3 Series": 80,
    "Audi A4": 75,
    "Ford Mustang": 90
};

function updateCarImage() {
    const carModel = document.getElementById('carModel').value;
    const pricePerDayField = document.getElementById('pricePerDay');

    if (carModel && carPrices[carModel]) {
        pricePerDayField.value = carPrices[carModel];
    } else {
        pricePerDayField.value = '';
    }

    document.getElementById('totalCost').value = '';
}

function calculateTotalCost() {
    const rentalDays = parseInt(document.getElementById('rentalDays').value);
    const pricePerDay = parseFloat(document.getElementById('pricePerDay').value);

    if (isNaN(rentalDays) || rentalDays <= 0 || isNaN(pricePerDay) || pricePerDay <= 0) {
        alert("Please make sure you have selected a valid car model and entered valid rental days.");
        return false; // Prevent form submission
    }

    const totalCost = rentalDays * pricePerDay;
    document.getElementById('totalCost').value = totalCost.toFixed(2);

    return true;
}

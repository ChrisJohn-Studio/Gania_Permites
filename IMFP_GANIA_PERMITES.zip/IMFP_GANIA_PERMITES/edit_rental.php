<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_rental";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch rental details based on the rental ID
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    $sql = "SELECT * FROM rentals WHERE id = $edit_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Get the price per day for the car model
        $car_model = $row['car_model'];
        $price_per_day = $row['price_per_day'];
    } else {
        die("Rental record not found.");
    }
}

// Handle the form submission and update the record
if (isset($_POST['update'])) {
    $newCarModel = $_POST['carModel'];
    $newRentalDays = $_POST['rentalDays'];

    // Fetch the price per day for the new car model
    $priceQuery = "SELECT price_per_day FROM cars WHERE car_model = '$newCarModel'";
    $priceResult = $conn->query($priceQuery);

    if ($priceResult->num_rows > 0) {
        $priceRow = $priceResult->fetch_assoc();
        $price_per_day = $priceRow['price_per_day'];
    } else {
        echo "Car model not found!";
        exit();
    }

    // Calculate the total cost
    $total_cost = $price_per_day * $newRentalDays;

    // Update the rental record
    $updateQuery = "UPDATE rentals SET car_model = '$newCarModel', rental_days = $newRentalDays, price_per_day = $price_per_day, total_cost = $total_cost WHERE id = $edit_id";
    
    if ($conn->query($updateQuery) === TRUE) {
        header('Location: view_rentals.php'); // Redirect back to view rentals page after successful update
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Rental</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-size: 1.1em;
            color: #333;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 12px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        .btn {
            background-color: #007BFF;
            color: white;
            padding: 12px 20px;
            text-align: center;
            font-size: 1em;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .btn-back {
            background-color: #ccc;
            text-decoration: none;
            color: #333;
            padding: 12px 20px;
            border-radius: 6px;
            display: inline-block;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Rental Details</h1>

        <form method="POST" action="">
            <!-- Car Model Field -->
            <div class="form-group">
                <label for="carModel">Car Model</label>
                <input type="text" id="carModel" name="carModel" value="<?php echo htmlspecialchars($row['car_model']); ?>" required>
            </div>

            <!-- Rental Days Field -->
            <div class="form-group">
                <label for="rentalDays">Rental Days</label>
                <input type="number" id="rentalDays" name="rentalDays" value="<?php echo htmlspecialchars($row['rental_days']); ?>" required>
            </div>

            <!-- Update Button -->
            <div class="form-group">
                <button type="submit" name="update" class="btn">Update Rental</button>
            </div>
        </form>

        <a href="view_rentals.php" class="btn-back">Back to Rentals</a>
    </div>

</body>
</html>

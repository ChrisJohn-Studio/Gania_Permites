<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_rental";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $carModel = $_POST['carModel'];
    $rentalDays = $_POST['rentalDays'];
    $pricePerDay = $_POST['pricePerDay'];
    $totalCost = $_POST['totalCost'];

    // Calculate total cost based on rental days and price per day
    if (!empty($rentalDays) && !empty($pricePerDay)) {
        $totalCost = $rentalDays * $pricePerDay;
    }

    // Update the rental in the database
    $stmt = $conn->prepare("UPDATE rentals SET car_model = ?, rental_days = ?, price_per_day = ?, total_cost = ? WHERE id = ?");
    $stmt->bind_param("ssddi", $carModel, $rentalDays, $pricePerDay, $totalCost, $id);

    if ($stmt->execute()) {
        echo "Rental updated successfully.";
        header("Location: view_rentals.php");  // Redirect to the rentals list page
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

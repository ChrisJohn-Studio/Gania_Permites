<?php
// Database connection
$servername = "localhost";  // Database server (usually localhost)
$username = "root";         // Database username (change to your username)
$password = "";             // Database password (change to your password)
$dbname = "car_rental";     // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$name = $_POST['name'];
$carModel = $_POST['carModel'];
$rentalDays = $_POST['rentalDays'];
$pricePerDay = $_POST['pricePerDay'];
$totalCost = $_POST['totalCost'];

// Validate form data
if (empty($name) || empty($carModel) || empty($rentalDays) || empty($pricePerDay) || empty($totalCost)) {
    die("All fields are required.");
}

// Prepare the SQL query to insert data into the rentals table
$stmt = $conn->prepare("INSERT INTO rentals (name, car_model, rental_days, price_per_day, total_cost) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssidd", $name, $carModel, $rentalDays, $pricePerDay, $totalCost);

// Execute the query
if ($stmt->execute()) {
    // Successfully inserted into the database, now show a message and redirect
    echo "<!DOCTYPE html>
          <html lang='en'>
          <head>
              <meta charset='UTF-8'>
              <meta name='viewport' content='width=device-width, initial-scale=1.0'>
              <title>Insertion Successful</title>
              <script>
                  // Show the confirmation message
                  alert('Inserted into Database');
                  // Redirect to the view page after 5 seconds
                  setTimeout(function() {
                      window.location.href = 'view_rentals.php';
                  }, 5000);
              </script>
          </head>
          <body>
              <h2>Your car rental information has been inserted into the database. You will be redirected to the rentals page in 5 seconds...</h2>
          </body>
          </html>";
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
